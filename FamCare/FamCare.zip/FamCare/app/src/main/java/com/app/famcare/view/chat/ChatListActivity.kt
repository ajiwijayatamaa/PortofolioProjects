package com.app.famcare.view.chat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.app.famcare.R

class ChatListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)
    }
}